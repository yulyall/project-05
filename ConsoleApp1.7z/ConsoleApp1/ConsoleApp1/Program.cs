﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите интервал а");
            int a = int.Parse(Console.ReadLine());

            Console.WriteLine("Введите интервал b");
            int b = int.Parse(Console.ReadLine());

            int c1, c2;
            c1 = 0;
            bool f;
            Console.WriteLine("Числа палиндрома от {0} до {1}:", a, b);
            int c, k;
            for (int i = a; i <= b; i++)
            {
                c = i;
                k = 0;
                f = true;
                while (c != 0)
                {
                    k++;
                    c /= 10;
                }
                c2 = 1;
                if (i >= 10)
                    for (int j = k; j >= k / 2; j--)
                    {
                        c1 = (int)Math.Pow(10, j - 1);
                        if ((i / c1 % 10) != (i / c2) % 10) f = false;
                        c2 *= 10;
                    }
                if (f) Console.Write("{0,7}", i);
            }
            Console.ReadKey();
        }
    }
}
